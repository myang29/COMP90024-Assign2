<template>
    <div class="wrath-types">
        <h2>Wrath Type</h2>

        <button onclick="update(wrathdata)"> Wrath Data</button>
        <button onclick="update(aurinData)"> {{ aurinType }}</button>
         <!-- :on="generateBarChart" -->
        <!-- <svg ref="barChart" class="bar-chart">
        </svg> -->
    </div>
    
</template>


<script>
export default {
    name: 'wrathtypedata',
    props: {
        wrathdata: Array,
        aurinData: Array,
        aurinType: String
    },
    methods:{
        generateBarChart() {
            var charData = this.chartData,

            margin = {top: 30, right: 30, bottom: 70, left: 60},
                width = 200 - margin.left - margin.right,
                height = 199 - margin.top - margin.bottom;

            var chartSvg = d3.select(this.$refs.baseBarChart)
                .append("svg")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform",
                    "translate(" + margin.left + "," + margin.top + ")");

            // X axis
            var x = d3.scaleBand()
                .range([ 0, width ])
                .domain(wrathdata.map(function(d) { return d.group; }))
                .padding(0.2);
            svg.append("g")
                .attr("transform", "translate(0," + height + ")")
                .call(d3.axisBottom(x))

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 20])
                .range([ height, 0]);
            svg.append("g")
                .attr("class", "myYaxis")
                .call(d3.axisLeft(y));
        },
        update(data){
            var u = svg.selectAll("rect")
                .data(data)

            u
                .enter()
                .append("rect")
                .merge(u)
                .transition()
                .duration(1000)
                .attr("x", function(d) { return x(d.group); })
                .attr("y", function(d) { return y(d.value); })
                .attr("width", x.bandwidth())
                .attr("height", function(d) { return height - y(d.value); })
                .attr("fill", "#69b3a2")
            }
    },
    data: {
        return() {

        }
    },
    mounted: function(){
         // Initialize the plot with the first dataset
        this.update(wrathdata)
    }
}
</script>


<style scoped>
.wrath-types {
    border: 1px solid black;
    text-align: center;
    background:  white;
    color: #2c3e50;
    width: 32%;
    border-radius: 10px;
    block-size: 22em;
    padding-top: 0.1px;
    margin-top: 10px;
    float: left;
    /* display:inline;   */
    margin-left: 1%;
    /* margin-right: 24%; */

}
</style>
