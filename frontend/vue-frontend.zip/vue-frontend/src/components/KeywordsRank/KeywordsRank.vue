<template>
    <div class="keywords-rank-container">
        <h2>Keywords Rank</h2>

        <!-- <div class="word-cloud" id="wordCloud" :style="{width: '100%',height:'100%'}"></div> -->
        <!-- <vue-word-cloud
            :words="extractWords"
            :color="([, weight]) => weight > 10 ? 'DeepPink' : weight > 5 ? 'RoyalBlue' : 'Indigo'"
            font-family="Roboto"></vue-word-cloud> -->
        <!-- <wordcloud
            :data="wordsFreq"
            nameKey="key"
            valueKey="value"
            :color="myColors"
            :showTooltip="true"
            :wordClick="wordClickHandler">Test??
        </wordcloud> -->
        <cloud :data="words" :fontSizeMapper="fontSizeMapper" />
    </div>
    
</template>


<script>
// import 'echarts-wordcloud/dist/echarts-wordcloud'
// import 'echarts-wordcloud/dist/echarts-wordcloud.min'

import wordcloud from 'vue-wordcloud'
export default {
    name: 'keywordsrank',

    mounted() {
        // this.drawCloud()
    },
    components: {
        wordcloud
    },
    props: {
        wordsFreq: Array
    },
    methods: {
        wordClickHandler(name, value, vm) {
            console.log('wordClickHandler', name, value, vm);
        }
        // extractWords(){
        //     let data=[];
        //     for (var i=0; i < this.wordsFreq.length; i++){
        //         let obj = [];
        //         obj.append(this.wordsFreq[i].key)
        //         obj.append(this.wordsFreq[i].value)
        //         data.push(obj)
        //     }

        // }

    },
    data() {
        return {
            myColors: ['#1f77b4', '#629fc9', '#94bedb', '#c9e0ef'],
        }
    }
}
</script>


<style scoped>

.keywords-rank-container {
    border: 1px solid black;
    text-align: center;
    background:  white;
    color: #2c3e50;
    width: 32%;
    border-radius: 10px;
    block-size: 22em;
    padding-top: 0.1px;
    margin-top: 10px;
    margin-right: 1%;
    float: right;
    height: 500px;
}

.word-cloud {
    margin-top: 5px;
    margin-left: 5px;
    margin-right: 5px;
}

</style>
