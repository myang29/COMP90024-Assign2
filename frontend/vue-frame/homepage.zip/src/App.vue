<template>
  <div id="app">
    <home></home>
  </div>
</template>
<script>
import Home from "./components/home";
export default {
  components: {
    Home
  }
};
</script>

