export const rate = {
  "rows": [
    { "key": "Adelaide", "value": [1742, 42370] },
    { "key": "Brisbane", "value": [3863, 92980] },
    { "key": "Canberra", "value": [720, 22041] },
    { "key": "Darwin", "value": [100, 2007] },
    { "key": "Hobart", "value": [134, 2174] },
    { "key": "Melbourne", "value": [12156, 227662] },
    { "key": "Perth", "value": [2457, 56483] },
    { "key": "Sydney", "value": [12013, 257129] }
  ]
}
